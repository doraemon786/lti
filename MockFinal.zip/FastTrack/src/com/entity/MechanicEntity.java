package com.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Mechanic")
public class MechanicEntity {
	
	@Id
	@Column(name="mechanicID")
	private int mechanicID;
	@Column(name="mechanicType")
	private String mechanicType;
	@Column(name="numberOfVehicles")
	private int numberOfVehicles;
	
	public int getMechanicID() {
		return mechanicID;
	}
	public void setMechanicID(int mechanicID) {
		this.mechanicID = mechanicID;
	}
	public String getMechanicType() {
		return mechanicType;
	}
	public void setMechanicType(String mechanicType) {
		this.mechanicType = mechanicType;
	}
	public int getNumberOfVehicles() {
		return numberOfVehicles;
	}
	public void setNumberOfVehicles(int numberOfVehicles) {
		this.numberOfVehicles = numberOfVehicles;
	}
	

}
