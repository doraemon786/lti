package com.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ServiceRegister")
public class ServiceRegisterEntity {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="serviceId")
	private int serviceId;
	@Column(name="vehicleNo")
	private String vehicleNo;
	@Column(name="vehicleType")
	private String vehicleType;
	@Column(name="mechanicId")
	private int mechanicID;
	
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getVehicleNo() {
		return vehicleNo;
	}
	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	public int getMechanicID() {
		return mechanicID;
	}
	public void setMechanicID(int mechanicID) {
		this.mechanicID = mechanicID;
	}
	
	
}
