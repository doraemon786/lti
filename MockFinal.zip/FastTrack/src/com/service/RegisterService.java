package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bean.Register;
import com.dao.RegisterDAO;
import com.exception.InvalidTypeException;
import com.bean.Mechanic;

@Component
public class RegisterService {
	@Autowired
	RegisterDAO dao;
	
	public int registerForService(Register register) throws Exception{
		System.out.println(register.getVehicleType()+" "+dao.getMechanicType(register.getMechanicID()));
		if(!(register.getVehicleType().equalsIgnoreCase(dao.getMechanicType(register.getMechanicID()))))
			throw new InvalidTypeException();
		int serviceID = dao.registerForService(register);
		return serviceID;		
	}
	
	public List<Mechanic> getAllMechanic(){
		List<Mechanic> mechanics = dao.getAllMechanic();
		return mechanics;
	}
	public List<Register> getAllServieDetails(){
		List<Register> registers = dao.getAllServiceDetails();
		return registers;
	}
}
