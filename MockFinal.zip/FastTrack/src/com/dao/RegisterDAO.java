package com.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.bean.Mechanic;
import com.bean.Register;
import com.entity.MechanicEntity;
import com.entity.ServiceRegisterEntity;

@Component
public class RegisterDAO {
	
	@PersistenceContext
	EntityManager em;
	
	
	public List<Mechanic> getAllMechanic(){
		List<Mechanic> mechanicDetails = new ArrayList<Mechanic>();
		Query qq = em.createQuery("SELECT m FROM MechanicEntity m");
		List<MechanicEntity> mechanicEntities = qq.getResultList();
		for(MechanicEntity mEntity : mechanicEntities){
			Mechanic mechanic = new Mechanic();
			mechanic.setMechanicID(mEntity.getMechanicID());
			mechanic.setMechanicType(mEntity.getMechanicType());
			mechanicDetails.add(mechanic);
		}
		return mechanicDetails;
	}
	public String getMechanicType(int mechanicID){
		MechanicEntity mEntity = em.find(MechanicEntity.class , mechanicID);
		String mechanicType = mEntity.getMechanicType();
		return mechanicType;
	}
	@Transactional
	public int registerForService(Register register){
		// retrieve the details (mechanic Id and mechanic type) of all mechanics 
		ServiceRegisterEntity serviceRegisterEntity = new ServiceRegisterEntity();
		serviceRegisterEntity.setMechanicID(register.getMechanicID());
		serviceRegisterEntity.setVehicleNo(register.getVehicleNo());
		serviceRegisterEntity.setVehicleType(register.getVehicleType());
		em.persist(serviceRegisterEntity);
		// update the numberofVehicle by incrementing by 1 for the selected mechanic Id 
		MechanicEntity mechanicEntity = em.find(MechanicEntity.class, register.getMechanicID());
		mechanicEntity.setNumberOfVehicles(mechanicEntity.getNumberOfVehicles()+1);
		//Return the generated service Id
		int serviceID = serviceRegisterEntity.getServiceId();		
		return serviceID;
	}
	
	public List<Register> getAllServiceDetails(){
		List<Register> registerDetails = new ArrayList<Register>();
		// retrieve all records from serviceRegister table 
		Query qq = em.createQuery("SELECT s FROM ServiceRegisterEntity s");
		List<ServiceRegisterEntity> registerEntities = qq.getResultList();
		for(ServiceRegisterEntity sEntity : registerEntities){
			Register register = new Register();
			register.setMechanicID(sEntity.getMechanicID());
			register.setServiceId(sEntity.getServiceId());
			register.setVehicleNo(sEntity.getVehicleNo());
			register.setVehicleType(sEntity.getVehicleType());
			registerDetails.add(register);
		}
		return registerDetails;
	}
}
