package com.exception;

public class InvalidTypeException extends Exception{
	public InvalidTypeException(){
		super("Vehicle type and Mechanic type are not matching");
	}
}
