package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.bean.Register;
import com.service.RegisterService;

@Controller
public class ReportController {

	@Autowired
	RegisterService service;

	@RequestMapping(value="/reportForm.htm")
	public ModelAndView displayServiceReport(){
		ModelAndView mView=new ModelAndView();
		try{
			List<Register> serviceList=service.getAllServieDetails();
			System.out.println(" Service Report page");
			System.out.println(serviceList);
			mView.addObject("serviceList", serviceList);
			mView.setViewName("/report");
		}catch(Exception e){
			mView.addObject("MESSAGE","ERROR: "+ e.getMessage());
			mView.setViewName("/report");
		}
		return mView;
	}
}
