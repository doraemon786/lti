package com.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bean.Mechanic;
import com.bean.Register;
import com.service.RegisterService;

@Controller
public class RegisterController {

	@Autowired
	RegisterService service;
	
	@RequestMapping("/home.htm")
	public ModelAndView displayHomePage(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("home");
		return modelAndView;

	}
	
	@RequestMapping("/addRegisterForm.htm")
	public ModelAndView displayRegisterForm(ModelMap map){
		Register register = new Register();
		map.addAttribute(register);
		ModelAndView mView=new ModelAndView();
		mView.setViewName("registerVehicle");
		return mView;
	}
	
	@ModelAttribute("mechanicIDList")
	public Map<Integer,Integer> populateMechId(){
		
		List<Mechanic> allMechanics = service.getAllMechanic();
		Map<Integer,Integer> mechanicMap=new HashMap<Integer,Integer>();
				
		for(Mechanic mechanic : allMechanics){
			mechanicMap.put(mechanic.getMechanicID(), mechanic.getMechanicID());
		}
		return mechanicMap;
	}
	
	@ModelAttribute("mechanicTypeList")
	public Map<String,String> populateMechType(){
		List<Mechanic> allMechanics = service.getAllMechanic();
		Map<String,String> mechanicMap=new HashMap<String,String>();
				
		for(Mechanic mechanic : allMechanics){
			mechanicMap.put(mechanic.getMechanicType(), mechanic.getMechanicType());
		}
		return mechanicMap;
	}
	
	@RequestMapping(value="/registerVehicle.htm",method=RequestMethod.GET)
	public ModelAndView addServiceDetails(@ModelAttribute Register register){
		ModelAndView mView=new ModelAndView();
		try {
			Integer serviceID = service.registerForService(register);
			mView.addObject("MESSAGE", "Service Registration successful, ServiceID : "+serviceID);
			mView.setViewName("/registerVehicle");
		}catch(Exception e){
			mView.addObject("MESSAGE","ERROR: "+ e.getMessage());
			mView.setViewName("/registerVehicle");
		}
		return mView;
	}
}
