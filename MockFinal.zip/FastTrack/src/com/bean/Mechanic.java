package com.bean;

public class Mechanic {
	private int mechanicID;	
	private String mechanicType;
	private int numberOfVehicles;
	
	public int getMechanicID() {
		return mechanicID;
	}
	public void setMechanicID(int mechanicID) {
		this.mechanicID = mechanicID;
	}
	public String getMechanicType() {
		return mechanicType;
	}
	public void setMechanicType(String mechanicType) {
		this.mechanicType = mechanicType;
	}
	public int getNumberOfVehicles() {
		return numberOfVehicles;
	}
	public void setNumberOfVehicles(int numberOfVehicles) {
		this.numberOfVehicles = numberOfVehicles;
	}
}
