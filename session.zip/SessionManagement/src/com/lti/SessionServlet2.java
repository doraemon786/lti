package com.lti;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Users;


public class SessionServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
   HttpSession session;
    public SessionServlet2() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	 session = request.getSession(false);
	Users user=(Users)session.getAttribute("sessionuser");
	response.getWriter().print("<h2>Welcome"+user.getUsername()+"</h2>");
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
