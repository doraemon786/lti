package com.lti;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Users;

public class ServletSession3 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ServletSession3() {
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Users user = null;
		user.setUsername(request.getParameter("username"));
		request.getRequestDispatcher("new.jsp").forward(request, response);
		
	}

		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doGet(request,response);
			
			
		
	}

}
