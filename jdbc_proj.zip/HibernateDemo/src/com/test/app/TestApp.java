package com.test.app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
//import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.Transaction;

import com.test.model.Customer;

import lti.util.HibernateUtil;

public class TestApp {

	public static void main(String[] args) {

/*		AnnotationConfiguration config = new AnnotationConfiguration();
		config.configure().buildSessionFactory();
		config.addAnnotatedClass(Customer.class);*/
		
		Customer c1 = new Customer("Mark","NY",230,30);
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		
		Transaction tx = session.beginTransaction();
		session.save(c1);
		System.out.println("Customer Data Save. . . ");
		tx.commit();
		System.out.println("Closing Session");
		session.close();
		
		
	}

}
