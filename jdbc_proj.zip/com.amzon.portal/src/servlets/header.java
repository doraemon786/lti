package servlets;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/header")
public class header extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  HashMap<String, String> map= new HashMap<String,String>();
    public header() {
        super();
  
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Enumeration<String> headernames= request.getHeaderNames();
		while(headernames.hasMoreElements())
		{
			String headername=headernames.nextElement();
			String headervalue = request.getHeader(headername);
			map.put(headervalue, headername);
		}
		request.setAttribute("map_of_header", map);
		request.getRequestDispatcher("header.jsp").forward(request, response);
		
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
