package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/hitCounter")
public class hitCounter extends HttpServlet {
	 private PrintWriter out;
	private RequestDispatcher rd;
  static int count=0;
    public hitCounter() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	 count++;
		out=response.getWriter();
		out.println("  servlet counter is"+ count);
		rd=request.getRequestDispatcher("index.jsp");
		rd.include(request, response);

	}

}
