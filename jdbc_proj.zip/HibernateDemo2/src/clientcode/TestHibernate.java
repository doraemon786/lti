package clientcode;

import java.util.GregorianCalendar;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import model.employee;

public class TestHibernate {
	@PersistenceContext
	 static EntityManager manager;
	public static void main(String[] args) {
	

		
		employee e1= new employee();
		
	Configuration config= new Configuration();
	SessionFactory sfactory=config.configure().buildSessionFactory();
	Session session= sfactory.openSession();
	Transaction tx=(Transaction) session.beginTransaction();
	
	e1.setEmail("mm@gmail.com");
	e1.setJoiningDate("sdfs");
	e1.setLoginTime("dfsf");
	e1.setName("shanal");
	e1.setPassword("mitali");

	e1.setPermanent(true);
	

	session.saveOrUpdate(e1);
	
	try {
		tx.commit();
	} catch (SecurityException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (RollbackException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (HeuristicMixedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (HeuristicRollbackException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SystemException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	session.close();
	e1.setEmail("kk@gmail.com");
	
	Session session1= sfactory.getCurrentSession();
	session1.save(e1);

	}

}
