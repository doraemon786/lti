package model;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class employee{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int id;
	private String name;
	private String password;
	private  String Email;
	

	private String JoiningDate;


	private String loginTime; 
	private boolean isPermanent;
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}

	public String getJoiningDate() {
		return JoiningDate;
	}
	public void setJoiningDate(String string) {
		JoiningDate = string;
	}
	
	public String getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(String string) {
		this.loginTime = string;
	}
	public boolean isPermanent() {
		return isPermanent;
	}
	public void setPermanent(boolean isPermanent) {
		this.isPermanent = isPermanent;
	}
	public employee(int id, String name, String password, String email, String joiningDate, String loginTime,
			boolean isPermanent) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		Email = email;
		JoiningDate = joiningDate;
		this.loginTime = loginTime;
		this.isPermanent = isPermanent;
	}
	public employee() {
		super();

	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", password=" + password + ", Email=" + Email
				+ ", JoiningDate=" + JoiningDate + ", loginTime=" + loginTime + ", isPermanent=" + isPermanent + "]";
	}
	

}
