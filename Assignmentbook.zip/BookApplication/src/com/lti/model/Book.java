package com.lti.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Book {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
int bookid;
String Bookname;
String AuthorName;
String  price;


public int getBookid() {
	return bookid;
}
public void setBookid(int bookid) {
	this.bookid = bookid;
}
public String getBookname() {
	return Bookname;
}
public void setBookname(String bookname) {
	Bookname = bookname;
}
public String getAuthorName() {
	return AuthorName;
}
public void setAuthorName(String authorName) {
	AuthorName = authorName;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
public Book( String bookname, String authorName, String price) {
	super();

	Bookname = bookname;
	AuthorName = authorName;
	this.price = price;
}
public Book() {
	super();
	
}
@Override
public String toString() {
	return "Book [bookid=" + bookid + ", Bookname=" + Bookname + ", AuthorName=" + AuthorName + ", price=" + price
			+ "]";
}


}
