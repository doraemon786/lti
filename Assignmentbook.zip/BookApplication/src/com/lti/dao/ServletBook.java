package com.lti.dao;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.model.Book;

@WebServlet("/ServletBook")
public class ServletBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static BookDaoImpl bdao= new BookDaoImpl();

    public ServletBook() {
        super();
     
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
			String bookname=request.getParameter("bookname");
		String authorname=request.getParameter("authorname");
		String price=request.getParameter("price");
		System.out.println(price+" "+authorname);
		Book b1= new Book( bookname, authorname, price);
	bdao.addBook(b1);
	
	
			
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
