package com.lti.dao;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.lti.model.Book;

import lti.util.HibernateUtil;





public class BookDaoImpl implements IBookDao{

	@Override
	public void addBook(Book b) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session =  factory.openSession();
	
		Transaction tx = session.beginTransaction();
		
		Book bk= new Book(b.getBookname(), b.getAuthorName(), b.getPrice());
		session.saveOrUpdate(bk);
		tx.commit();
		
		System.out.println("Bid Added Successfully");
		
		session.close();
	
	}

	@Override
	public void deleteBook(Book b) {
	
		
	}

	@Override
	public void updateBook(Book b) {
	
		
	}

	@Override
	public List<Book> showBook(Book b) {
	
		return null;
	}



}
