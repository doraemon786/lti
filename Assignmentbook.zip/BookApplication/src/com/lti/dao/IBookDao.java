package com.lti.dao;


import java.util.List;

import com.lti.model.Book;

public interface IBookDao {

	public void  addBook(Book b);
	public void deleteBook(Book b);
	public void updateBook(Book b);
	public List<Book> showBook(Book b);
}
