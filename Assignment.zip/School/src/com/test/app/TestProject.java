package com.test.app;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import com.test.model.Module;
import com.test.model.Project;
import com.test.model.Task;

import lti.util.HibernateUtil;

public class TestProject {

	public static void main(String[] args) {
		
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session =  factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		Project p1 = new Project();
		p1.setStartDate(LocalDate.of(2019, 01, 05).toString());
		p1.setTitle("Banking");
		int idp1 = (int) session.save(p1);
		
		Module m1 = new Module();
		m1.setModuleName("Withdrawl");
		m1.setId(p1.getId());
		session.save(m1);
		
		Task  t1 = new Task();
		t1.setId(p1.getId());
		t1.setModuleName(m1.getModuleName());
		t1.setTaskName("Exception Handling");
		session.save(t1);
		
		Project p2 = new Project();
		p2.setStartDate(LocalDate.of(2019, 01, 05).toString());
		p2.setTitle("ECommerce");
		int idp2 = (int) session.save(p2);
		
		Module m2 = new Module();
		m2.setModuleName("Shopping Cart");
		m2.setId(p2.getId());
		session.save(m2);
		
		Task  t2 = new Task();
		t2.setId(p1.getId());
		t2.setModuleName(m2.getModuleName());
		t2.setTaskName("Documentation");
		session.save(t2);
		
		tx.commit();
		Query query=session.createQuery("from Project as p");
		List<Project> list=query.list();
		for(Project element:list)
		{
			System.out.println(element);
		}
		session.close();
		
		
	}

}
