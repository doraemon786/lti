package com.test.app;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import com.test.model.Airline;
import com.test.model.flight;

import lti.util.HibernateUtil;

public class TestFlight {

	public static void main(String[] args) {

		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session =  factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		flight flight1= new flight();
		
		flight1.setCapacity(40);
		flight1.setFromSector("Delhi");
		flight1.setToSector("Chandigarh");
	
		
		Airline airline1 = new Airline("Emirates");

		Airline airline2 = new Airline("Indigo");

		
	List<Airline> arrlist= new ArrayList<>();
	arrlist.add(airline1);
	arrlist.add(airline2);
	flight1.setAirlineList(arrlist);
	session.saveOrUpdate(flight1);
		tx.commit();
		System.out.println("data saved.....");
		session.close();

	}

}
