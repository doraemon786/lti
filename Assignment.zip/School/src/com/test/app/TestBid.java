package com.test.app;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.test.model.Bid;
import com.test.model.BidDaoImpl;

public class TestBid {
	static Scanner sc= new Scanner(System.in);
	 static BidDaoImpl bdao = new BidDaoImpl();
	public static void main(String[] args) {

	
	while(true)
	{
		System.out.println("Enter Your Choice");
		System.out.println("1.addbid");
		System.out.println("2.deletebid");
		System.out.println("3.updatebid");
		System.out.println("4.fetchAllBid");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:AddBid();
		break;
		case 2:DeleteBid();
		break;
		case 3:UpdateBid();
		break;
		case 4:FetchBid();
		break;
		
		}
		}
	}
private static void AddBid() {
		System.out.println("enter Amount");
		int amount=sc.nextInt();
		System.out.println("enter Quantity");
		int quanity=sc.nextInt(); 
		System.out.println("enter your Farmer-id");
		int id=sc.nextInt();

		Bid bid= new Bid(id, amount, quanity);
	bdao.addBid(bid);
		
	}

	private static void DeleteBid() {
		System.out.println("enter id to remove");
		int bidid=sc.nextInt();
		bdao.deletBid(bidid);
		
	}

	private static void UpdateBid() {
		System.out.println("enter the bid id to update");
		int id= sc.nextInt();
		System.out.println("enter Amount");
		int amount=sc.nextInt();
		System.out.println("enter Quantity");
		int quantity=sc.nextInt();
		System.out.println("enter your Farmer-id");
		int farmerid=sc.nextInt();
		Bid bd= new Bid(farmerid, amount, quantity);
		bdao.updateBid(bd,id);
		
	}

	private static void FetchBid() {
	List<Bid> list=bdao.ListById();
		for(int i=0;i<list.size();i++)
		{
			System.out.println(list.get(i));
		}
		
	}

}
