package com.test.app;


import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import com.test.model.School;
import com.test.model.SchoolDetails;

import lti.util.HibernateUtil;

public class TestSchool {

	public static void main(String[] args) {
		
	
	SchoolDetails schooldetails = new SchoolDetails();
	
	schooldetails.setAddress("Santacruz");
	schooldetails.setStudentcount(10000);
	schooldetails.setPublic(false);

	School school  = new School("Podar International",schooldetails);
		
	SessionFactory factory = HibernateUtil.getSessionFactory();
	Session session =  factory.openSession();
	Transaction tx = session.beginTransaction();
	session.save(school);
	System.out.println("Data saved");
	tx.commit();
	session.close();

	}

}
