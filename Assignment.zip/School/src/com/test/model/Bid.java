package com.test.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Bid {

@Id
@GeneratedValue(strategy=GenerationType.AUTO)
	int bidid;
	int farmerid;
	int amount;
	int quantity;
	
	public Bid(int farmerid, int amount, int quantity) {
		super();
		
		this.farmerid = farmerid;
		this.amount = amount;
		this.quantity = quantity;
	}

	public int getBidid() {
		return bidid;
	}

	public void setBidid(int bidid) {
		this.bidid = bidid;
	}

	public int getFarmerid() {
		return farmerid;
	}

	public void setFarmerid(int farmerid) {
		this.farmerid = farmerid;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Bid [bidid=" + bidid + ", farmerid=" + farmerid + ", amount=" + amount + ", quantity=" + quantity + "]";
	}
	 public Bid() {
		// TODO Auto-generated constructor stub
	}
	
}
