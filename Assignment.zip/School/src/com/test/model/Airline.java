package com.test.model;

public class Airline {
	private int AirlineId;
	private String AirlineName;
	
	public Airline() {
		super();
}

	public Airline(String airlineName) {
		super();
	//	AirlineId = airlineId;
		this.AirlineName = airlineName;
	}

	@Override
	public String toString() {
		return "Airline [AirlineId=" + AirlineId + ", AirlineName=" + AirlineName + "]";
	}

	public int getAirlineId() {
		return AirlineId;
	}

	public void setAirlineId(int airlineId) {
		AirlineId = airlineId;
	}

	public String getAirlineName() {
		return AirlineName;
	}

	public void setAirlineName(String airlineName) {
		AirlineName = airlineName;
	}
	
	}
