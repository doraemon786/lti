package com.test.model;

import java.util.ArrayList;
import java.util.List;

public interface IBidDao {

	void addBid(Bid bid);
	void deletBid(int id);
	void  updateBid(Bid bid,int id);
	
	List<Bid> ListById();
}
