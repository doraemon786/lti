package com.test.model;

import javax.persistence.Embeddable;

@Embeddable
public class SchoolDetails {
private int studentcount;
private boolean isPublic;
private String address;
public SchoolDetails(int studentcount, boolean isPublic, String address) {
	super();
	this.studentcount = studentcount;
	this.isPublic = isPublic;
	this.address = address;
}
public SchoolDetails() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "SchoolDetails [studentcount=" + studentcount + ", isPublic=" + isPublic + ", address=" + address + "]";
}
public int getStudentcount() {
	return studentcount;
}
public void setStudentcount(int studentcount) {
	this.studentcount = studentcount;
}
public boolean isPublic() {
	return isPublic;
}
public void setPublic(boolean isPublic) {
	this.isPublic = isPublic;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public void setSchoolDetails() {
	// TODO Auto-generated method stub
	
}

}
