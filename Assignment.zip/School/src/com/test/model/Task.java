package com.test.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;


@Entity
public class Task extends Module {
private String TaskName;

public String getTaskName() {
	return TaskName;
}

public void setTaskName(String taskName) {
	TaskName = taskName;
}

@Override
public String toString() {
	return "Task [TaskName=" + TaskName + "]";
}

public Task(String taskName) {
	super();
	TaskName = taskName;
}

public Task() {
	super();
	// TODO Auto-generated constructor stub
}

public Task(int id, String title, String startDate, String moduleName) {
	super(id, title, startDate, moduleName);
	// TODO Auto-generated constructor stub
}

public Task(int id, String title, String startDate) {
	super(id, title, startDate);
	// TODO Auto-generated constructor stub
}


}
