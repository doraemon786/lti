package com.test.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
@Entity
public class Module extends Project{
private String ModuleName;

public Module() {
	super();
	// TODO Auto-generated constructor stub
}

public Module(int id, String title, String startDate) {
	super(id, title, startDate);
	// TODO Auto-generated constructor stub
}

public Module(int id, String title, String startDate, String moduleName) {
	super(id, title, startDate);
	ModuleName = moduleName;
}

@Override
public String toString() {
	return "Module [ModuleName=" + ModuleName + "]";
}

public String getModuleName() {
	return ModuleName;
}

public void setModuleName(String moduleName) {
	ModuleName = moduleName;
}


}
