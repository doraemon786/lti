package com.test.model;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import lti.util.HibernateUtil;

public class BidDaoImpl implements IBidDao {

	@Override
	public void addBid(Bid bid) {
	
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session =  factory.openSession();
	
		Transaction tx = session.beginTransaction();
		
		Bid bd= new Bid(bid.farmerid, bid.amount, bid.quantity);
		session.saveOrUpdate(bd);
		tx.commit();
		System.out.println("Bid Added Successfully");
		session.close();
		
	}

	@Override
	public void deletBid(int id) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session =  factory.openSession();
		
		Transaction tx = session.beginTransaction();
		try{
			Bid bid = (Bid)session.load(Bid.class,id);
		session.delete(bid);
		tx.commit();
		System.out.println("Bid deleted Successfully");
		}
		catch(Exception e)
		{
			System.out.println("Bid deleted Successfully");
		}
		session.close();
		
	}

	@Override
	public void  updateBid(Bid bid,int id) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session =  factory.openSession();
		
		Transaction tx = session.beginTransaction();
		Bid bid1 = (Bid)session.load(Bid.class,id);
		bid1.setAmount(bid.getAmount());
		bid1.setFarmerid(bid.getFarmerid());
		bid1.setQuantity(bid.getQuantity());
		session.update(bid1);
		tx.commit();
		System.out.println("Bid Updated Successfully");
		session.close();
	}

	@Override
	public List<Bid> ListById() {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session =  factory.openSession();
		
		Transaction tx = session.beginTransaction();
	Query query=session.createQuery("from Bid");
	List list=query.list();
	return list;
	}

}
