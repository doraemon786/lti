package com.test.model;

import java.util.List;

public class flight {
private int flightId;
private String fromSector;
private String toSector;
private int capacity;

private List<Airline> airlineList;


public List<Airline> getAirlineList() {
	return airlineList;
}
public void setAirlineList(List<Airline> airlineList) {
	this.airlineList = airlineList;
}

public flight(String fromSector, String toSector, int capacity) {
	super();
//	this.flightId = flightId;
	this.fromSector = fromSector;
	this.toSector = toSector;
	this.capacity = capacity;
}
public flight() {
	super();
	// TODO Auto-generated constructor stub
}
public int getFlightId() {
	return flightId;
}
public void setFlightId(int flightId) {
	this.flightId = flightId;
}
public String getFromSector() {
	return fromSector;
}
public void setFromSector(String fromSector) {
	this.fromSector = fromSector;
}
public String getToSector() {
	return toSector;
}
public void setToSector(String toSector) {
	this.toSector = toSector;
}
public int getCapacity() {
	return capacity;
}
public void setCapacity(int capacity) {
	this.capacity = capacity;
}
@Override
public String toString() {
	return "flight [airlineList=" + airlineList + "]"+this.getAirlineList();
}


}
