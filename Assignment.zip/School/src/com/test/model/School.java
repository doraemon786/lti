package com.test.model;

import java.io.Serializable;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class School implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private int id;
private String name; 	

private SchoolDetails schooldetails;



public int getId() {
	return id;
}
public int setId() {
	return id;
}



public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
@Embedded
public SchoolDetails getSchooldetails() {
	return schooldetails;
}

public void setSchooldetails(SchoolDetails schooldetails) {
	this.schooldetails = schooldetails;
}

public School( String name, SchoolDetails schooldetails) {
	super();

	this.name = name;
	this.schooldetails = schooldetails;
}

public School() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "School [id=" + id + ", name=" + name + ", schooldetails=" + schooldetails + "]";
}



}
