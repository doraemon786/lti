package com.lnt.mvc.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.lnt.mvc.model.Department;
import com.lnt.mvc.model.EmployeeDetails;
@Repository
public class DepartmentDaoImpl implements DepartmentDAO {
private static SessionFactory sessionFactory;

	@Override
	public void createDepartment(Department Department) {
	 this.sessionFactory.getCurrentSession().save(Department);
		
	}

	@Override
	public void updateDepartment(Department Department) {
		sessionFactory.getCurrentSession().update(Department);
		List<Department> employeeList = sessionFactory.getCurrentSession().createQuery("from Department").list();
for(Department dept:employeeList)
{
	System.out.println(dept);
}
	
	}

	@Override
	public void deleteDepartment(int DeparmentId) {
	 
	//	Department department = (Department) this.sessionFactory(Department.class,new Integer(DeparmentId));
	//	this.sessionFactory.getCurrentSession().delete(department);
	}

	@Override
	public List<Department> getAllDeparment() {
		 
		Session session = this.sessionFactory.getCurrentSession();
		List<Department> employeeList = session.createQuery("from Department").list();
				return employeeList;
	}

	@Override
	public Department getDeparment(int DepartmentId) {
		Session session = this.sessionFactory.getCurrentSession();
		Department deptdetails = (Department) session.load(Department.class, new Integer(DepartmentId));
		return deptdetails ;
	}

}
