package com.lnt.mvc.dao;

import java.util.List;

import com.lnt.mvc.model.Department;
import com.lnt.mvc.model.EmployeeDetails;

public interface DepartmentDAO {

	public void createDepartment(Department Department);
	
	public void updateDepartment(Department Department);
	
public void deleteDepartment(int DeparmentId);
	
	public List<Department> getAllDeparment();
	
	public Department getDeparment(int DepartmentId);
}
