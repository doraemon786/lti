package com.lnt.mvc.dao;



import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.jboss.logging.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.lnt.mvc.model.EmployeeDetails;
import com.lnt.mvc.model.Person;
@Repository
public class EmployeeDetailsDaoImpl implements EmployeeDetailsDAO{
SessionFactory sessionFactory;
	private static final Logger logger = (Logger) LoggerFactory.getLogger(EmployeeDetailsDaoImpl.class);
	
	@Override
	public void createEmployeeDetails(EmployeeDetails EmployeeDetails) {
		 System.out.println("Entered 1");
		 Session session  = this.sessionFactory.openSession();
		 session.save(EmployeeDetails);
		 
		 logger.info("Employee Details saved successfully , Employee Details" + EmployeeDetails);
		
	}

	@Override
	public void updateEmployeeDetails(EmployeeDetails EmployeeDetails) {
		 sessionFactory.openSession().update(EmployeeDetails);
		 logger.info("Employee Details update successfully"
				 +"Employee Details" + EmployeeDetails);
		
	}

	@Override
	public void deleteEmployeeDetails(int EmployeeDetailsId) {
		
		Session session = this.sessionFactory.openSession();
		EmployeeDetails employeeDetails = ( EmployeeDetails ) session.load(EmployeeDetails.class, 
				new Integer(EmployeeDetailsId));
		if(null != employeeDetails)
		{
			session.delete(employeeDetails);
		}
		else
		{
			logger.error
			("Employee  NOT deleted, with Employee Id=" +EmployeeDetailsId);
		}
		
	}

	@Override
	public List<EmployeeDetails> getAllEmployeeDetails() {
	 
		Session session = this.sessionFactory.openSession();
		List<EmployeeDetails> employeeList = session.createQuery("from EmployeeDetails").list();
		for (EmployeeDetails emp : employeeList) {
			logger.info("Employee List::" + emp);
		}
		return employeeList;
	}
		

	@Override
	public EmployeeDetails getEmployeeDetails(int EmployeeDetailsId) {
		 
		Session session = this.sessionFactory.openSession();
		EmployeeDetails empdetails = (EmployeeDetails) session.load(EmployeeDetails.class, new Integer(EmployeeDetailsId));
		logger.info("Employee Details loaded successfully, EmployeeDetails=" + empdetails);
		return empdetails;
	}

	@Override
	public List<EmployeeDetails> getByNameEmp(String name) {
	 String hql = "from EmployeeDetails e where e.firstName like :names";
	 Session session = this.sessionFactory.openSession();
	 Query query = (Query) session.createQuery(hql);
	 query.setParameter("names",name+"%");
	 List<EmployeeDetails> emp = query.getResultList();
	 
		return emp;
	}
 
	
}
