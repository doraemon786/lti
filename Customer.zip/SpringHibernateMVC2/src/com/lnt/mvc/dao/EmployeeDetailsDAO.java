package com.lnt.mvc.dao;

import java.util.List;

import com.lnt.mvc.model.EmployeeDetails;

public interface EmployeeDetailsDAO {

	public void createEmployeeDetails(EmployeeDetails EmployeeDetails);
	
	public void updateEmployeeDetails(EmployeeDetails EmployeeDetails);
	
	public void deleteEmployeeDetails(int EmployeeDetailsId);
	
	public List<EmployeeDetails> getAllEmployeeDetails();
	
	public EmployeeDetails getEmployeeDetails(int EmployeeDetailsId);
	
	public List<EmployeeDetails> getByNameEmp(String name);
}
