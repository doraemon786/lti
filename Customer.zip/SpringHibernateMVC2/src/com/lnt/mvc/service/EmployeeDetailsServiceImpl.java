package com.lnt.mvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.mvc.dao.EmployeeDetailsDAO;
import com.lnt.mvc.model.EmployeeDetails;
@Service
@Transactional
public class EmployeeDetailsServiceImpl  implements EmployeeDetailsDAO {

	@Autowired
	EmployeeDetailsDAO empdao;
	@Override
	public void createEmployeeDetails(EmployeeDetails EmployeeDetails) {
		empdao.createEmployeeDetails(EmployeeDetails);
		
	}

	@Override
	public void updateEmployeeDetails(EmployeeDetails EmployeeDetails) {
		empdao.updateEmployeeDetails(EmployeeDetails);
		
	}

	@Override
	public void deleteEmployeeDetails(int EmployeeDetailsId) {
		empdao.deleteEmployeeDetails(EmployeeDetailsId);
	}

	@Override
	public List<EmployeeDetails> getAllEmployeeDetails() {
	List<EmployeeDetails>	l=empdao.getAllEmployeeDetails();
		return l;
	}

	@Override
	public EmployeeDetails getEmployeeDetails(int EmployeeDetailsId) {
		
		return empdao.getEmployeeDetails(EmployeeDetailsId);
	}

	@Override
	public List<EmployeeDetails> getByNameEmp(String name) {
	List<EmployeeDetails> l=	empdao.getByNameEmp(name);
		return l;
	}

}
