package com.lnt.mvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.mvc.dao.DepartmentDAO;
import com.lnt.mvc.model.Department;
@Transactional
@Service
public class DepartmentService implements IDepartmentService {
 @Autowired
 DepartmentDAO idao;
	@Override
	public void createDepartment(Department Department) {
		idao.createDepartment(Department);
		
	}

	@Override
	public void updateDepartment(Department Department) {
		idao.updateDepartment(Department);
	}

	@Override
	public void deleteDepartment(int DeparmentId) {
		idao.deleteDepartment(DeparmentId);
		
	}

	@Override
	public List<Department> getAllDeparment() {
		List<Department>l=idao.getAllDeparment();
		return l;
	}

	@Override
	public Department getDeparment(int DepartmentId) {
	
		return idao.getDeparment(DepartmentId);
	}

}
