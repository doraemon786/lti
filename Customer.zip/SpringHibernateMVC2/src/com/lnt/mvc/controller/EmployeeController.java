package com.lnt.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


import com.lnt.mvc.model.EmployeeDetails;


@Controller
public class EmployeeController {
	
	@RequestMapping(value="/employees")
	public String callform(Model model) {
		model.addAttribute("EmployeeDetails", new EmployeeDetails());// model
	
		return "employee";// view name
	}
}
